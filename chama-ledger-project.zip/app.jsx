import ChamaLedger from "./ChamaLedger";

export default function App() {
  return <ChamaLedger />;
}